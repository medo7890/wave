const reviewsContainer = document.getElementById('reviews');

async function loadReviews() {
    const res = await fetch('http://localhost:3000/api/reviews/product/PRODUCT_ID'); // استبدل PRODUCT_ID بالمنتج المناسب
    const reviews = await res.json();
    reviewsContainer.innerHTML = '<h2>Customer Reviews</h2>';
    reviews.forEach(r => {
        const div = document.createElement('div');
        div.className = 'review-card';
        div.innerHTML = `
            <h4>${r.user.firstName} ${r.user.lastName} - ${r.rating}⭐</h4>
            <strong>${r.title}</strong>
            <p>${r.comment}</p>
        `;
        reviewsContainer.appendChild(div);
    });
}

loadReviews();