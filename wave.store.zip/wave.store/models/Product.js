const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    name: { type: String, required: true, trim: true },
    description: { type: String, trim: true },
    price: { type: Number, required: true },
    originalPrice: Number,
    category: { type: String, enum: ['hoodie','pants','set','accessory'], default: 'hoodie' },
    image: { type: String, required: true },
    images: [String],
    sizes: { type: [String], default: ['M','L','XL'], enum: ['XS','S','M','L','XL','2XL','3XL'] },
    colors: { type: [String], default: ['Black','White'] },
    stock: { type: Number, default: 0 },
    featured: { type: Boolean, default: false },
    discount: { type: Number, default: 0 },
    rating: {
        average: { type: Number, default: 0 },
        count: { type: Number, default: 0 }
    },
    tags: [String],
    sku: { type: String, unique: true, sparse: true },
    status: { type: String, enum: ['active','out_of_stock','discontinued'], default: 'active' }
}, { timestamps: true });

productSchema.virtual('discountPrice').get(function() {
    return this.discount > 0 ? this.price * (1 - this.discount/100) : this.price;
});

productSchema.pre('save', function(next) {
    if (!this.sku) this.sku = this.category.substring(0,3).toUpperCase()+'-'+Math.floor(100000 + Math.random()*900000);
    next();
});

module.exports = mongoose.model('Product', productSchema);