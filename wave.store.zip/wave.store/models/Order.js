const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    orderNumber: { type: String, unique: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    items: [{
        product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
        name: String,
        price: Number,
        quantity: { type: Number, default: 1 },
        size: String,
        color: String,
        image: String
    }],
    shippingAddress: {
        firstName: String, lastName: String, street: String, city: String, state: String,
        country: String, zipCode: String, phone: String
    },
    billingAddress: {
        firstName: String, lastName: String, street: String, city: String, state: String,
        country: String, zipCode: String
    },
    subtotal: Number,
    shippingCost: Number,
    tax: Number,
    total: Number,
    paymentMethod: { type: String, enum: ['cod','visa','mastercard','paypal','vodafone'], required: true },
    paymentStatus: { type: String, enum: ['pending','completed','failed','refunded'], default: 'pending' },
    status: { type: String, enum: ['pending','processing','shipped','delivered','cancelled'], default: 'pending' },
    createdAt: { type: Date, default: Date.now }
}, { timestamps: true });

orderSchema.pre('save', function(next) {
    if (!this.orderNumber) {
        const date = new Date();
        this.orderNumber = `ORD-${date.getFullYear()}${(date.getMonth()+1).toString().padStart(2,'0')}-${Math.floor(1000+Math.random()*9000)}`;
    }
    next();
});

module.exports = mongoose.model('Order', orderSchema);