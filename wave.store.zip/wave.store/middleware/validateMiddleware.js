// ============================================
// VALIDATION MIDDLEWARE
// ============================================

const validate = {
    // تحقق من بيانات المنتج قبل الإضافة أو التعديل
    product: (req, res, next) => {
        const { name, price, category } = req.body;

        if (!name || !name.trim()) {
            return res.status(400).json({
                success: false,
                message: 'Product name is required'
            });
        }

        if (!price || isNaN(price) || price < 0) {
            return res.status(400).json({
                success: false,
                message: 'Valid price is required'
            });
        }

        if (!category || !['hoodie', 'pants', 'set', 'accessory'].includes(category)) {
            return res.status(400).json({
                success: false,
                message: 'Valid category is required'
            });
        }

        next();
    },

    // تحقق من بيانات الطلب قبل الإنشاء
    order: (req, res, next) => {
        const { items, shippingAddress, paymentMethod } = req.body;

        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Order items are required'
            });
        }

        if (!shippingAddress || !shippingAddress.street || !shippingAddress.city) {
            return res.status(400).json({
                success: false,
                message: 'Valid shipping address is required'
            });
        }

        if (!paymentMethod || !['cod', 'visa', 'mastercard', 'paypal', 'vodafone'].includes(paymentMethod)) {
            return res.status(400).json({
                success: false,
                message: 'Valid payment method is required'
            });
        }

        next();
    },

    // تحقق من بيانات المستخدم قبل التسجيل أو التعديل
    user: (req, res, next) => {
        const { email, password } = req.body;

        if (!email || !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Valid email is required'
            });
        }

        if (!password || password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters'
            });
        }

        next();
    }
};

module.exports = validate;