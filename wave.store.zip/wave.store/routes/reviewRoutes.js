const express = require('express');
const Review = require('../models/Review');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// كل مراجعات منتج
router.get('/product/:productId', async (req, res) => {
    const reviews = await Review.find({ product: req.params.productId, status: 'approved' }).populate('user','firstName lastName');
    res.json(reviews);
});

// إضافة مراجعة جديدة
router.post('/:productId', authMiddleware('customer'), async (req, res) => {
    const review = new Review({
        product: req.params.productId,
        user: req.user.id,
        ...req.body
    });
    await review.save();
    res.json({ message: 'Review submitted, pending approval', review });
});

// اعتماد أو رفض مراجعات (Admin)
router.put('/:id/status', authMiddleware('admin'), async (req, res) => {
    const { status } = req.body; // approved, rejected
    const review = await Review.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json(review);
});

module.exports = router;