const express = require('express');
const Order = require('../models/Order');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// إنشاء طلب جديد
router.post('/', authMiddleware('customer'), async (req, res) => {
    const order = new Order({ user: req.user.id, ...req.body });
    await order.save();
    res.json(order);
});

// الحصول على كل الطلبات (Admin)
router.get('/', authMiddleware('admin'), async (req, res) => {
    const orders = await Order.find().populate('user','firstName lastName email');
    res.json(orders);
});

// الحصول على طلب واحد
router.get('/:id', authMiddleware(), async (req, res) => {
    const order = await Order.findById(req.params.id).populate('user','firstName lastName email');
    res.json(order);
});

// تحديث حالة الطلب (Admin)
router.put('/:id/status', authMiddleware('admin'), async (req, res) => {
    const { status, paymentStatus } = req.body;
    const order = await Order.findByIdAndUpdate(req.params.id, { status, paymentStatus }, { new: true });
    res.json(order);
});

module.exports = router;