const express = require('express');
const Product = require('../models/Product');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// الحصول على كل المنتجات
router.get('/', async (req, res) => {
    const products = await Product.find();
    res.json(products);
});

// إنشاء منتج جديد (لوحة ادمن)
router.post('/', authMiddleware('admin'), async (req, res) => {
    const product = new Product(req.body);
    await product.save();
    res.json(product);
});

// تحديث منتج
router.put('/:id', authMiddleware('admin'), async (req, res) => {
    const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
});

// حذف منتج
router.delete('/:id', authMiddleware('admin'), async (req, res) => {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ message: 'Product deleted' });
});

// الحصول على منتج واحد
router.get('/:id', async (req, res) => {
    const product = await Product.findById(req.params.id);
    res.json(product);
});

module.exports = router;