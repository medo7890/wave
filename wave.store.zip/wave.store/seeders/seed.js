require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Product = require('../models/Product');
const User = require('../models/User');
const Review = require('../models/Review');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/waveStore';

const sampleProducts = [
    { name: 'Urban Classic Hoodie', description: 'Premium cotton hoodie', price: 59.99, originalPrice:79.99, category:'hoodie', image:'/uploads/placeholder-hoodie.jpg', sizes:['M','L','XL'], colors:['Black','Gray'], stock:50, featured:true, discount:25, tags:['urban','classic','premium'] },
    { name: 'Street Fit Pants', description: 'Comfortable streetwear pants', price:49.99, originalPrice:64.99, category:'pants', image:'/uploads/placeholder-pants.jpg', sizes:['M','L','XL'], colors:['Black','Olive'], stock:30, featured:true, discount:23, tags:['streetwear','casual'] },
    { name: 'Premium Hoodie & Pants Set', description:'Complete streetwear set', price:99.99, originalPrice:129.99, category:'set', image:'/uploads/placeholder-set.jpg', sizes:['M','L','XL'], colors:['Black','Gray'], stock:20, featured:true, discount:23, tags:['set','bundle','premium'] }
];

const sampleReviews = [
    { rating:5, title:'Great Hoodie', comment:'Loved the quality and fit!', verifiedPurchase:true },
    { rating:4, title:'Nice Pants', comment:'Comfortable and stylish', verifiedPurchase:true },
    { rating:5, title:'Awesome Set', comment:'Complete look, premium quality', verifiedPurchase:true }
];

const seedDatabase = async () => {
    try {
        await mongoose.connect(MONGODB_URI);
        console.log('MongoDB connected for seeding');

        await Product.deleteMany({});
        await User.deleteMany({});
        await Review.deleteMany({});

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD, salt);

        const adminUser = new User({ email:process.env.ADMIN_EMAIL, password:hashedPassword, firstName:'Admin', lastName:'User', role:'admin', isActive:true });
        await adminUser.save();

        const products = await Product.insertMany(sampleProducts);

        const customer = new User({ email:'customer@example.com', password:await bcrypt.hash('customer123', salt), firstName:'John', lastName:'Doe', role:'customer', isActive:true });
        await customer.save();

        for (const prod of products) {
            for (const reviewData of sampleReviews) {
                const review = new Review({ ...reviewData, product: prod._id, user: customer._id, status:'approved' });
                await review.save();
            }
        }

        console.log('Database seeded successfully');
        process.exit(0);
    } catch (error) {
        console.error('Error seeding database:', error);
        process.exit(1);
    }
};

seedDatabase();