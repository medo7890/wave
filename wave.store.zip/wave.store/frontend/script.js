const productsContainer = document.getElementById('products');

async function loadProducts() {
    const res = await fetch('http://localhost:3000/api/products');
    const products = await res.json();
    productsContainer.innerHTML = '';
    products.forEach(prod => {
        const div = document.createElement('div');
        div.className = 'product-card';
        div.innerHTML = `
            <img src="${prod.image}" alt="${prod.name}">
            <h3>${prod.name}</h3>
            <p>${prod.description}</p>
            <p class="price">$${prod.discountPrice || prod.price}</p>
        `;
        productsContainer.appendChild(div);
    });
}

loadProducts();